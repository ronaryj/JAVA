/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controllers;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import services.UserService;
import modele.User;

/**
 * FXML Controller class
 *
 * @author user
 */
public class VLoginController implements Initializable {

    @FXML
    private Button btnSeconnecter;
    @FXML
    private Tab tconnexion;
    @FXML
    private TextField clogin;
    @FXML
    private Tab tenregistrement;
    @FXML
    private TextField enom;
    @FXML
    private TextField eprenom;
    @FXML
    private TextField elogin;
    @FXML
    private TextField epassword;
    @FXML
    private Button btnenregistrer;

   private UserService userService;
    @FXML
    private PasswordField cpassword;
    @FXML
    private TabPane tabtab;
    public static User user;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.userService = new UserService();
    }    

    @FXML
    private void handleSeconnecter(ActionEvent event) throws IOException {
        user =this.userService.findUserByLoginAndPassword(this.clogin.getText(), this.cpassword.getText());
        if(user!=null)
        {
        btnSeconnecter.getScene().getWindow().hide() ;
        Parent root = FXMLLoader.load(getClass().getResource("/views/FXMLDocument.fxml"));
        Stage stage=new Stage();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        }
        else{
            JOptionPane.showMessageDialog(null,"Vos identifiants sont incorrects");
        }
    }

    @FXML
    private void handleEnregistrer(Event event) {
        if(this.userService.createUser(this.enom.getText(), this.eprenom.getText(), this.elogin.getText(), this.epassword.getText())){
        this.tenregistrement.setClosable(true);
        this.tabtab.getTabs().remove(1);
        this.tabtab.getTabs().add(tenregistrement);
        JOptionPane.showMessageDialog(null, "Veuillez vous connecter");
        }
    }
    
}
