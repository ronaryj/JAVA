/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import modele.User;


/**
 *
 * @author hp
 */
public class UserDao implements IDao<User> {

    private final String SQL_BY_LOGIN_AND_PASSWORD="Select * From users where login =? AND password=?";
    private final String SQL_BY_LOGIN="Select * From users where login =?";
     private final String SQL_BY_ID="Select * From users where id =? ";
    private final String SQL_INSERT="INSERT INTO `users`(`id`, `nom`, `prenom`, `login`, `password`) VALUES (NULL,?,?,?,?)";
    
    private MysqlDB mysql;

    public UserDao() {
        mysql=new MysqlDB();
    }
    
    
    @Override
    public int create(User obj) {
        int result=0;
        try {
              mysql.initPS(SQL_INSERT);
              mysql.getPstm().setString(1, obj.getNom());
              mysql.getPstm().setString(2, obj.getPrenom());
              mysql.getPstm().setString(3, obj.getLogin());
              mysql.getPstm().setString(4, obj.getPassword());
              mysql.executeMaj();
              ResultSet rs=mysql.getPstm().getGeneratedKeys();
              if(rs.first())  result=rs.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
        mysql.CloseConnexion();
        }
        System.out.println(result);
        return result;
    }

    @Override
    public boolean update(User obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public ArrayList<User> selectAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public User selectById(int id) {
        try {
            //PreparedStatement ps = cnx.prepareStatement(requete);
            mysql.initPS(SQL_BY_ID);
            //ps.setString(1, numero);
            mysql.getPstm().setInt(1, id);
            ResultSet rs = mysql.executeSelect();
            if(rs.first()){
                User cl = new User();
                cl.setId(rs.getInt("id"));
                cl.setLogin(rs.getString("login"));
                cl.setNom(rs.getString("nom"));
                cl.setPrenom(rs.getString("prenom"));
                return cl;
            }
          
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return null;
    }

    @Override
    public User selectByNumero(String numero){
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public User selectByLoginAndPassword(String login,String password) {
        try {
            mysql.initPS(SQL_BY_LOGIN_AND_PASSWORD);
            mysql.getPstm().setString(1, login);
            mysql.getPstm().setString(2, password);
            ResultSet rs = mysql.executeSelect();
            if(rs.first()){
                User user = new User();
                user.setId(rs.getInt("id"));
                user.setLogin(rs.getString("login"));
                user.setNom(rs.getString("nom"));
                user.setPrenom(rs.getString("prenom"));
                return user;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    
    public boolean verifLoginExist(String login) {
        try {
            mysql.initPS(SQL_BY_LOGIN);
            mysql.getPstm().setString(1, login);
            ResultSet rs = mysql.executeSelect();
            if(rs.first()){
                return true;
            }
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    
}
