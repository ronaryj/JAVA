/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

import dao.UserDao;
import javax.swing.JOptionPane;
import modele.User;

/**
 *
 * @author USER
 */
public class UserService {
    private UserDao userDao;
    
    public UserService(){
        userDao = new UserDao();
    }
    
    public boolean createUser(String nom,String prenom,String login,String password){
        if(userDao.verifLoginExist(login)){
            JOptionPane.showMessageDialog(null, "Ce nom d'utilisateur existe déjà");
            return false;
        }
        return userDao.create(new User(nom,prenom,login,password))!=0;
    }
    
    public User findUserByLoginAndPassword(String login,String password){
        return this.userDao.selectByLoginAndPassword(login, password);
    }
}
